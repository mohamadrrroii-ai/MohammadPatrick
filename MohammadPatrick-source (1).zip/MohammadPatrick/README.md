# Mohammad Patrick — Milestone 1 (Android)

A first-stage native Android project for the Mohammad Patrick Persian personal assistant. This milestone focuses on the app shell and local login security only.

## Implemented in source

- Native Kotlin Android app, RTL Persian interface, dark navy/blue visual theme.
- Initial login verifier uses PBKDF2-HMAC-SHA256 (210,000 iterations) with a salt; the initial password is not stored as plain text.
- Forces a password change after the first successful login.
- Password change validates current password, minimum length (10 characters), confirmation, and rejects reuse of the current password.
- Temporary lockout after five failed attempts, with increasing delay capped at five minutes.
- Locks after five minutes of inactivity and when the app leaves the foreground.
- Disables Android backup and uses FLAG_SECURE to reduce screenshot/recents exposure.
- Clearly marks future features as not yet implemented.

## Not implemented yet

AI API/backend, web search, voice capture, wake word, speaker verification, device controls, memory/history database, image OCR, and background listening are not connected in this milestone.

## Build on Windows

1. Install Android Studio and a JDK 17 (Android Studio's bundled JBR is suitable).
2. In Android Studio, choose **Open** and select this `MohammadPatrick` folder.
3. Allow Gradle sync. The project uses Android Gradle Plugin 8.7.3, Kotlin Android plugin 2.0.21, compile SDK 35 and target SDK 34. Install Android SDK Platform 35 if prompted.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.
6. For a release APK, configure signing in Android Studio; do not share the signing key.

## First launch

Initial password: `mohamadtnt13`

After the first successful login, the app requires changing it to a new password of at least 10 characters. The initial verifier is embedded in the APK, so this is suitable as a local first-run gate, not as a replacement for server-backed identity. A determined person with APK access may analyze or brute-force an embedded verifier. No AI API key is included in this project.

## Important security/implementation notes

- This is an early milestone, not a finished assistant.
- The inactivity timer is best-effort app-level locking. Android process termination, force-stop, device-level behavior, and process scheduling can affect timing.
- `SharedPreferences` stores the salt and password verifier in app-private storage. A future security hardening pass should consider Android Keystore-backed encryption and threat-model review.
- No microphone or internet permissions are requested yet because those features are not implemented.

## Build validation status

The project files are provided for Android Studio/Gradle. This environment did not have an Android SDK or Gradle installation available, so an APK could not be compiled or device-tested here. Do not treat this milestone as compiled until you build it in Android Studio and test on the Galaxy A23.
