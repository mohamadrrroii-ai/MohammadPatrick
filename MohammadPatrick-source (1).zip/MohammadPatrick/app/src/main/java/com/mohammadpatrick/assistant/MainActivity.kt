package com.mohammadpatrick.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("mp_private_settings", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var unlocked = false
    private var lastInteraction = System.currentTimeMillis()
    private val autoLockMs = 5 * 60 * 1000L
    private val autoLockTask = object : Runnable {
        override fun run() {
            if (unlocked && System.currentTimeMillis() - lastInteraction >= autoLockMs) {
                lockApp("به دلیل عدم استفاده، برنامه قفل شد.")
            } else if (unlocked) {
                handler.postDelayed(this, 15_000L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = Color.rgb(8, 13, 27)
        window.navigationBarColor = Color.rgb(8, 13, 27)
        if (!prefs.contains(KEY_HASH)) {
            // PBKDF2 verifier only; the initial password is not stored as plain text.
            prefs.edit().putString(KEY_SALT, INITIAL_SALT).putString(KEY_HASH, INITIAL_HASH)
                .putBoolean(KEY_MUST_CHANGE, true).apply()
        }
        showLogin()
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        lastInteraction = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        if (unlocked) {
            lastInteraction = System.currentTimeMillis()
            handler.removeCallbacks(autoLockTask)
            handler.postDelayed(autoLockTask, 15_000L)
        }
    }

    override fun onPause() {
        super.onPause()
        // Require authentication again when leaving the app. This is intentionally conservative.
        if (unlocked) lockApp(null)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun showLogin(message: String? = null) {
        unlocked = false
        val root = baseLayout()
        root.gravity = Gravity.CENTER
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(24), dp(28), dp(24))
        }
        content.addView(orb(112))
        content.addView(text("محمد پاتریک", 30, BLUE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(4)) })
        content.addView(text("دستیار شخصی هوشمند", 15, MUTED).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(26)) })
        if (message != null) content.addView(text(message, 14, WARNING).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(12)) })
        val password = EditText(this).apply {
            hint = "رمز ورود برنامه"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            textSize = 16f
            setTextColor(Color.WHITE)
            setHintTextColor(MUTED)
            gravity = Gravity.CENTER
            background = rounded(0xFF111B31.toInt(), 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        content.addView(password, LinearLayout.LayoutParams(-1, dp(54)))
        val login = button("ورود امن") {
            val until = prefs.getLong(KEY_LOCK_UNTIL, 0L)
            val now = System.currentTimeMillis()
            if (now < until) {
                showLogin("به دلیل تلاش‌های ناموفق، ${((until - now + 999) / 1000)} ثانیه دیگر تلاش کن.")
                return@button
            }
            val candidate = password.text.toString()
            if (candidate.isBlank()) {
                showLogin("رمز را وارد کن.")
            } else if (verifyPassword(candidate)) {
                prefs.edit().putInt(KEY_FAILS, 0).putLong(KEY_LOCK_UNTIL, 0L).apply()
                unlocked = true
                lastInteraction = System.currentTimeMillis()
                if (prefs.getBoolean(KEY_MUST_CHANGE, false)) {
                    showChangePassword(true)
                } else {
                    showHome()
                }
            } else {
                val fails = prefs.getInt(KEY_FAILS, 0) + 1
                val editor = prefs.edit().putInt(KEY_FAILS, fails)
                if (fails >= 5) {
                    val lockMs = minOf(5 * 60_000L, 30_000L * (1L shl minOf(fails - 5, 3)))
                    editor.putLong(KEY_LOCK_UNTIL, now + lockMs)
                }
                editor.apply()
                showLogin(if (fails >= 5) "رمز نادرست است؛ ورود موقتاً محدود شد." else "رمز نادرست است. تلاش ${fails} از ۵")
            }
        }
        content.addView(login, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(14) })
        content.addView(text("رمز اولیه فقط برای ورود به برنامه است؛ پس از ورود اول باید آن را تغییر بدهی.", 12, MUTED).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(18), 0, 0)
        })
        root.addView(content, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        password.requestFocus()
    }

    private fun showHome() {
        unlocked = true
        lastInteraction = System.currentTimeMillis()
        handler.removeCallbacks(autoLockTask)
        handler.postDelayed(autoLockTask, 15_000L)
        val root = baseLayout()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        content.addView(text("سلام، محمد!", 27, Color.WHITE, true).apply { setPadding(0, dp(10), 0, dp(5)) })
        content.addView(text("نسخه اولیه · هسته برنامه", 14, MUTED).apply { setPadding(0, 0, 0, dp(22)) })
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(0xFF101B33.toInt(), 24)
            setPadding(dp(18), dp(24), dp(18), dp(24))
        }
        hero.addView(orb(120))
        hero.addView(text("محمد پاتریک آماده توسعه است", 18, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(8)) })
        hero.addView(text("در این مرحله، ورود امن و قفل برنامه پیاده‌سازی شده‌اند. هوش مصنوعی و فرمان صوتی هنوز متصل نشده‌اند.", 14, MUTED).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER })
        content.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        content.addView(sectionButton("گفتگوی هوشمند", "اتصال به هوش مصنوعی آنلاین — مرحله بعد") { infoDialog("گفتگوی هوشمند", "این قابلیت هنوز پیاده‌سازی نشده است. مرحله بعد شامل سرور واسط امن و اتصال API خواهد بود.") })
        content.addView(sectionButton("فرمان صوتی", "میکروفون و عبارت بیدارباش — مرحله بعد") { infoDialog("فرمان صوتی", "ضبط صدا و تشخیص عبارت بیدارباش هنوز در این نسخه فعال نیست.") })
        content.addView(sectionButton("کنترل گوشی", "چراغ‌قوه، برنامه‌ها و صدا — مرحله بعد") { infoDialog("کنترل گوشی", "فرمان‌های سیستمی در مرحله بعد و به‌صورت جداگانه پیاده‌سازی و آزمایش می‌شوند.") })
        content.addView(sectionButton("حافظه و تاریخچه", "مدیریت اطلاعات شخصی — مرحله بعد") { infoDialog("حافظه و تاریخچه", "پایگاه داده حافظه هنوز اضافه نشده است.") })
        content.addView(button("تنظیمات امنیتی · تغییر رمز") { showChangePassword(false) }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        content.addView(button("قفل کردن برنامه") { lockApp("برنامه قفل شد.") }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }.also { })
        content.addView(text("قفل خودکار پس از ۵ دقیقه عدم تعامل؛ خروج از برنامه نیز باعث قفل شدن می‌شود.", 12, MUTED).apply { setPadding(dp(2), dp(18), dp(2), 0) })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun showChangePassword(required: Boolean) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0) }
        val oldPass = EditText(this).apply { hint = if (required) "رمز اولیه" else "رمز فعلی"; inputType = 129; setSingleLine(true) }
        val newPass = EditText(this).apply { hint = "رمز جدید (حداقل 10 نویسه)"; inputType = 129; setSingleLine(true) }
        val confirm = EditText(this).apply { hint = "تکرار رمز جدید"; inputType = 129; setSingleLine(true) }
        listOf(oldPass, newPass, confirm).forEach { box.addView(it, LinearLayout.LayoutParams(-1, dp(52))) }
        val dialog = AlertDialog.Builder(this).setTitle(if (required) "تغییر رمز اولیه" else "تغییر رمز ورود")
            .setMessage(if (required) "برای ادامه، رمز اولیه را به یک رمز شخصی تغییر بده." else "رمز جدید حداقل ۱۰ نویسه داشته باشد.")
            .setView(box).setCancelable(!required)
            .setPositiveButton("ذخیره", null)
            .apply { if (!required) setNegativeButton("انصراف", null) }
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val old = oldPass.text.toString()
                val fresh = newPass.text.toString()
                val repeated = confirm.text.toString()
                when {
                    !verifyPassword(old) -> Toast.makeText(this, "رمز فعلی نادرست است.", Toast.LENGTH_SHORT).show()
                    fresh.length < 10 -> Toast.makeText(this, "رمز جدید باید حداقل ۱۰ نویسه داشته باشد.", Toast.LENGTH_SHORT).show()
                    fresh != repeated -> Toast.makeText(this, "تکرار رمز با رمز جدید یکسان نیست.", Toast.LENGTH_SHORT).show()
                    fresh == old -> Toast.makeText(this, "رمز جدید باید با رمز فعلی متفاوت باشد.", Toast.LENGTH_SHORT).show()
                    else -> {
                        savePassword(fresh)
                        prefs.edit().putBoolean(KEY_MUST_CHANGE, false).putInt(KEY_FAILS, 0).putLong(KEY_LOCK_UNTIL, 0L).apply()
                        dialog.dismiss()
                        showHome()
                        Toast.makeText(this, "رمز جدید ذخیره شد.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        dialog.show()
        if (required) dialog.setCanceledOnTouchOutside(false)
    }

    private fun verifyPassword(candidate: String): Boolean {
        return try {
            val salt = Base64.getDecoder().decode(prefs.getString(KEY_SALT, INITIAL_SALT))
            val expected = Base64.getDecoder().decode(prefs.getString(KEY_HASH, INITIAL_HASH))
            val actual = derive(candidate, salt)
            MessageDigest.isEqual(expected, actual)
        } catch (_: Exception) { false }
    }

    private fun savePassword(password: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(password, salt)
        prefs.edit().putString(KEY_SALT, Base64.getEncoder().encodeToString(salt))
            .putString(KEY_HASH, Base64.getEncoder().encodeToString(hash)).apply()
    }

    private fun derive(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 210_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    private fun lockApp(message: String?) {
        unlocked = false
        handler.removeCallbacks(autoLockTask)
        showLogin(message)
    }

    private fun infoDialog(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("باشه", null).show()
    }

    private fun sectionButton(title: String, subtitle: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xFF101827.toInt(), 18)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        box.addView(text(title, 17, Color.WHITE, true))
        box.addView(text(subtitle, 13, MUTED).apply { setPadding(0, dp(5), 0, 0) })
        return box.also { it.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) } }
    }

    private fun baseLayout() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setBackgroundColor(BG)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 15f; setTextColor(Color.WHITE)
        background = rounded(BLUE_DARK, 16)
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun orb(size: Int): View = TextView(this).apply {
        text = "✦"; textSize = 50f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF173C72.toInt(), 0xFF286FC1.toInt(), 0xFF111B3B.toInt())).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(2), 0xFF65B8FF.toInt())
        }
        elevation = dp(8).toFloat()
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { gravity = Gravity.CENTER }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val KEY_SALT = "password_salt"
        private const val KEY_HASH = "password_hash"
        private const val KEY_MUST_CHANGE = "must_change_password"
        private const val KEY_FAILS = "failed_attempts"
        private const val KEY_LOCK_UNTIL = "lock_until"
        private const val INITIAL_SALT = "nyx6Uda4QOOkfRCcbiXxgw=="
        private const val INITIAL_HASH = "qzQzqaDOBr+LZ7cSOQ807nplNTrqEuMnquv9KMsSN08="
        private const val BG = 0xFF080D1B.toInt()
        private const val BLUE = 0xFF72B9FF.toInt()
        private const val BLUE_DARK = 0xFF174A83.toInt()
        private const val MUTED = 0xFF9BAAC3.toInt()
        private const val WARNING = 0xFFFFB86B.toInt()
    }
}
