package com.mohammadpatrick.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 20, 38)
    private val panel = Color.rgb(15, 35, 61)
    private val accent = Color.rgb(74, 166, 255)
    private val white = Color.rgb(239, 246, 255)
    private val muted = Color.rgb(164, 185, 210)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        val scrollContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = text("MOHAMMAD PATRICK", 24f, white, true).apply {
            letterSpacing = 0.04f
        }
        scrollContent.addView(title, matchWrap())
        scrollContent.addView(text("دستیار هوشمند فارسی", 17f, accent, true), marginParams(top = 10))
        val orb = TextView(this).apply {
            text = "✦"
            textSize = 62f
            gravity = Gravity.CENTER
            setTextColor(accent)
            setBackgroundColor(panel)
        }
        val orbParams = LinearLayout.LayoutParams(dp(150), dp(150)).apply {
            topMargin = dp(36)
            bottomMargin = dp(24)
        }
        scrollContent.addView(orb, orbParams)
        scrollContent.addView(text("سلام! من پاتریک هستم.", 20f, white, true), marginParams(bottom = 8))
        scrollContent.addView(text("این نسخه، پیش‌نمایش اولیه رابط برنامه است.", 14f, muted, false), marginParams(bottom = 24))

        val voiceButton = Button(this).apply {
            text = "🎙  شروع گفت‌وگوی صوتی"
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
            setOnClickListener {
                Toast.makeText(this@MainActivity, "قابلیت تشخیص صدا هنوز به این نسخه اضافه نشده است.", Toast.LENGTH_LONG).show()
            }
        }
        scrollContent.addView(voiceButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        val info = TextView(this).apply {
            text = "قابلیت‌های بعدی: قفل با رمز، تشخیص گفتار فارسی، اتصال امن به هوش مصنوعی و فرمان‌های مجاز گوشی."
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(panel)
        }
        scrollContent.addView(info, marginParams(top = 18))
        root.addView(scrollContent, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun marginParams(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = dp(top)
        bottomMargin = dp(bottom)
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
